#pragma once

//UI�}�l�[�W���[
#include "UI/HpGauge/HpGauge.h"
#include "UI/BossHPGauge/BossHpGauge.h"
#include "UI/UIBase/UIBase.h"
#include "UI/NowStatus/NowStatus.h"

class UIMng
{
public:

	//������
	void Init();
	//�ォ������
	void Term();
	//�X�V
	void Update();
	//�`��
	void Render();

	//�̗͂̊Ǘ�
	void SetHp(int hp);
	void SetIsBoss(bool isBoss);
	void SetBossHp(int hp);
	void SetScene(SceneType NextScene);
private:
	//�̗̓Q�[�W
	HPGauge mHpGauge;
	UIBase mUIBase;
	BossHPGauge mBossHPGeuge;
	NowStatus mNowStatus;
	SceneType mCurrentScene;

	bool mIsBoss;
};