﻿#include "App.h"

//シーンマネージャー
#include "Scene/SceneMng.h"
#include "GamePlayData/GamePlayData.h"
#include "Mst/StageDataMst.h"

SceneMng sceneMng;



//---------------------------------------------------------
//ゲームの初期化処理を行う関数
//---------------------------------------------------------
void App::Init() {
	//UI用の描画レイヤーを追加する
	RenderManager_I->AddLayer("UI");
	{
		//画面の左上がゲームの空間の原点0.0となるようにカメラ移動させる
		Camera camera;
		camera.SetPosition(WINDOW_WIDTH / 2.0f, -WINDOW_HEIGHT / 2.0f);
		RenderManager_I->SetCamera(camera);
	}

	{
		//UI用のカメラの追加設定
		Camera camera;
		//カメラ名を設定する
		camera.SetName("UI");
		//カメラのセット
		RenderManager_I->SetCamera(camera);
		//アクティブに
		RenderManager_I->SetLayerActive("UI", true);
		//レイヤにUIを設定
		camera.AddRenderLayer("UI");
		//カメラの位置を調整
		RenderManager_I->SetCameraPosition("UI", Vector2f(WINDOW_WIDTH / 2.0f, -WINDOW_HEIGHT / 2.0f));
		//UIカメラの描画対象からUIレイヤーを取り除く
		RenderManager_I->AddCameraRenderLayer("UI", "UI");
	}
	//新管理クラスの初期化
	sceneMng.Init(SceneType::Title);
	//ゲームプレイデータを初期化する
	GetGamePlayData().Init();
	//ステージ情報マスタを初期化する
	GetStageDataMst().Init();
}

//---------------------------------------------------------
//ゲームの更新処理を行う関数
//---------------------------------------------------------
void App::Update() {
//シーン更新
	sceneMng.Update();
}

//---------------------------------------------------------
//ゲームの描画処理を行う関数
//---------------------------------------------------------
void App::Render() {
	//シーン描画
	sceneMng.Render();
}
//---------------------------------------------------------
// ゲームの後片付け処理を行う関数
//---------------------------------------------------------
void App::Term() {
	//シーン開放
	sceneMng.Term();
}
