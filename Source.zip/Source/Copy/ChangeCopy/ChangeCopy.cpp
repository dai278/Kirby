//#include "Copy/ChangeCopy/ChangeCopy.h"
//#include "Copy/Sword/Sword.h"

//Sword sword;
//
//
////�R�s�[�̗͂�ύX���� 
//void ChangeCopy(CurrentCopy* cCopy, CopyAbility Ability) {
//	delete cCopy;
//	switch (Ability)
//	{
//	case cFire:
//		break;
//	case cBeam:
//		break;
//	case cSword:
//		cCopy =  &sword;
//		cCopy->Init();
//
//		break;
//	}
//	if (cCopy == NULL) {
//		cCopy = NULL;
//	}
//}