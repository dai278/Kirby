//#pragma once
//
//#include "Copy/CurrentCopy/CurrentCopy.h"
//#include "GameDef.h"
//
//void ChangeCopy(CurrentCopy* cCopy, CopyAbility Ability);

