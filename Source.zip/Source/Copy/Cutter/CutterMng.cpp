#include "CutterMng.h"

//--------------------------------------------
//������
//-------------------------------------------
void CutterMng::Init() {
	for (int i = 0; i < 3; ++i) {
		mCutter[i].Init();
	}
}

//-------------------------------------------
//�X�V����
//----------------------------------
void CutterMng::Update() {
	for (int i = 0; i < 3; ++i) {
			mCutter[i].Update();
	}
}

//--------------------------------------------------
//�`�揈��
//--------------------------------------------------
void CutterMng::Render() {
	for (int i = 0; i < 3; ++i) {
		if (mCutter[i].IsActive()) {
			mCutter[i].Render();
		}
	}
}

//------------------------------------------------
//�j��
//------------------------
void CutterMng::Term() {
	for (int i = 0; i < 3; ++i) {
			mCutter[i].Term();
	}
}


//------------------------------------------------
//�X�L���̎g�p
//------------------------------------------------
void CutterMng::UseSkill() {
	for (int i = 0; i < 3; ++i) {
		if (!mCutter[i].IsActive()) {
			mCutter[i].UseSkill();
			mCutter[i].SetPosition(mPosition);
			break;
		}
	}
}


//------------------------------------------------
//�X�L���g�p�\��
//------------------------------------------------
bool CutterMng::IsUse(){
	
	bool result = false;

	for (int i = 0; i < 3; ++i) {
		if (!mCutter[i].IsActive()) {
			result = true;
			break;
		}
	}
	return result;
}


//-------------------------------------------------
//�A�N�e�B�u���H
//------------------------------------------------
bool CutterMng::IsActive() {
	bool result = false;

	for (int i = 0; i < 3; ++i) {
		if (mCutter[i].IsActive()) {
			result = true;
			break;
		}
	}
	return result;
}


//----------------------------------------------
//�v���C���[���ړ���Ԃɂ��邩
//-----------------------------------------------
bool CutterMng::IsPlayerMoving() {
	bool result = true;

	for (int i = 0; i < 3; ++i) {
		if (mCutter[i].IsActive()&& mCutter[i].IsPlayerMoving()==false) {
			result = false;
			break;
		}
		else {
			1 + 1;
		}
	}
	return result;
}


//----------------------------------------------------
//�v���C���[���ړ�������^�C�v�̃R�s�[�\�͂�
//----------------------------------------------------
bool CutterMng::IsPlayerMove()const {
	return false;
}

//-----------------------------------------------------
//�v���C���[�𖳓G�ɂ��邩�H
//-----------------------------------------------------
bool CutterMng::IsPlayerInvincible()const{
	return false;
}

//-------------------------------------------------------
//�I�[�i�[�̃Z�b�g
//-------------------------------------------------------
void CutterMng::SetOwner(Character* owner) {
	for (int i = 0; i < 3; ++i) {
		mCutter[i].SetOwner(owner);
	}
}


//---------------------------------------------------
//��A�N�e�B�u��
//----------------------------------------------------
void CutterMng::InActive() {
	for (int i = 0; i < 3; ++i) {
		mCutter[i].InActive();
	}
}
