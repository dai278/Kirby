#include "WhispyWoodsAirBulletMng.h"


//--------------------------------------------
//������
//-------------------------------------------
void WhispyWoodsAirBulletMng::Init() {
	for (int i = 0; i < 4; ++i) {
		mWhispyWoodsAirBullet[i].Init();
	}

	mGenerateCount = 0;
}

//-------------------------------------------
//�X�V����
//----------------------------------
void WhispyWoodsAirBulletMng::Update() {

	for (int i = 0; i < 4; ++i) {
		if (mWhispyWoodsAirBullet[i].IsActive()) {
			mWhispyWoodsAirBullet[i].Update();
		}
	}
}

//--------------------------------------------------
//�`�揈��
//--------------------------------------------------
void WhispyWoodsAirBulletMng::Render() {
	for (int i = 0; i < 4; ++i) {
		if (mWhispyWoodsAirBullet[i].IsActive()) {
			mWhispyWoodsAirBullet[i].Render();
		}
	}
}

//------------------------------------------------
//�j��
//------------------------
void WhispyWoodsAirBulletMng::Term() {
	for (int i = 0; i < 4; ++i) {
		mWhispyWoodsAirBullet[i].Term();
	}
}


//------------------------------------------------
//�X�L���̎g�p
//------------------------------------------------
void WhispyWoodsAirBulletMng::UseSkill(const Vector2f generatePos) {
	for (int i = 0; i < 4; ++i) {
		if (!mWhispyWoodsAirBullet[i].IsActive()) {
			mWhispyWoodsAirBullet[i].UseSkill(generatePos);
			mWhispyWoodsAirBullet[i].SetPosition(generatePos);
			++mGenerateCount;
			break;
		}
	}
}


//---------------------------------------------------
//�����I���������H
//---------------------------------------------------
bool WhispyWoodsAirBulletMng::IsSkillGenerateEnd(int GenerateNum) {
	bool result = false;

	//��������������ΐ����I��
	if (mGenerateCount >= GenerateNum) {
		result = true;
		mGenerateCount = 0;
	}

	return result;
}


