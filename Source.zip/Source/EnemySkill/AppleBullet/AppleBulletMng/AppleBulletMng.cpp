//----------------------------------------
//�����S�e�}�l�[�W���[�N���X
//----------------------------------------
#include "AppleBulletMng.h"


//--------------------------------------------
//������
//-------------------------------------------
void AppleBulletMng::Init() {
	for (int i = 0; i < 3; ++i) {
		mAppleBullet[i].Init();
	}

	mGenerateCount = 0;
}

//-------------------------------------------
//�X�V����
//----------------------------------
void AppleBulletMng::Update() {
	
	for (int i = 0; i < 3; ++i) {
		if (mAppleBullet[i].IsActive()) {
			mAppleBullet[i].Update();

		}

	 	bool isActive= mAppleBullet[i].IsActive();
		int a=19;
	}

	bool isActive = mAppleBullet[0].IsActive();
	int a = 19;

}

//--------------------------------------------------
//�`�揈��
//--------------------------------------------------
void AppleBulletMng::Render() {
	for (int i = 0; i < 3; ++i) {
		if (mAppleBullet[i].IsActive()) {
			mAppleBullet[i].Render();
		}
	}
}

//------------------------------------------------
//�j��
//------------------------
void AppleBulletMng::Term() {
	for (int i = 0; i < 3; ++i) {
		mAppleBullet[i].Term();
	}
}


//------------------------------------------------
//�X�L���̎g�p
//------------------------------------------------
void AppleBulletMng::UseSkill(/*�����ʒu*/ Vector2f generatePos) {
	for (int i = 0; i < 3; ++i) {
		if (!mAppleBullet[i].IsActive()) {
			mAppleBullet[i].UseSkill();
			mAppleBullet[i].SetPosition(generatePos);
			++mGenerateCount;
			break;
		}

		if (mAppleBullet[i].IsActive()) {
			1 + 1;
		}
		else {
			1 + 1;
		}


	}
}

//------------------------------------------------
//�X�L���̐������I���������H
//------------------------------------------------
bool AppleBulletMng::IsSkillGenerateEnd() {
	//���ʂ�����
	bool result = false;

	//��������3�Ȃ琶���I��
	if (mGenerateCount == 3) {
		result = true;
		//���������O��
		mGenerateCount = 0;
	}

	return result;
}
