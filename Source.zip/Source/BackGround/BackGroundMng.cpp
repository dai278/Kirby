//---------------------------------------------------
//�w�i�Ǘ��N���X
//---------------------------------------------------

#include "BackGround/BackGroundMng.h"
#include "AppDef.h"
#include "GameObjectMng/GameObjectMng.h"

//------------------------------------------
//������
//------------------------------------------
void BackGroundMng::Init() {
	
	//�����ʒu
	float posX[2];
	posX[0] = WINDOW_WIDTH / 2;
	posX[1] = posX[0] + WINDOW_WIDTH;

	//����
	float posY = -365.0f;

	
	//������
	for (int i = 0; i < 2; ++i) {
		mBackGround[i].Init("Images/2dAction/BackGround.png");
		Vector2f pos = { posX[i],posY };
		mBackGround[i].SetPosition(pos);
	}
	
}


//-----------------------------------------
//�X�V����
//-----------------------------------------
void BackGroundMng::Update(Vector2f cameraPos) {
	for (int i = 0; i < 2; ++i) {
		mBackGround[i].Update(cameraPos);
	}
}


//------------------------------------------
//�`�揈��
//------------------------------------------
void BackGroundMng::Render() {
	for (int i = 0;i < 2;++i) {
		mBackGround[i].Render();
	}
}


//------------------------------------------
//�j��
//------------------------------------------
void BackGroundMng::Term() {
	for (int i = 0;i < 2;++i) {
		mBackGround[i].Term();
	}
}
