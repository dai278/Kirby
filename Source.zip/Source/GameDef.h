﻿#pragma once

//方向を示す定数
enum class Direction {
	Front,
	Right,
	Back,
	Left,
};

//辺
enum class Side {
	None = -1,

	Top,
	Right,
	Bttom,
	Left,
};

enum class CollisionGroup {
	Player,
	Skill,
	Enemy,
	EnemySkill,
	Boss,
	Goal,
	MoveAnotherMapObject,
	Suction,
	MapObject,
	CopyStar,
};

//シーンの種類
enum class SceneType
{
	None = -1,
	Title,
	InGame,
	GameOver,
	GameClear,
	StageSelect,
	SceneStageMovement
};

//現在の変身状態を示す列挙型
enum  CopyAbility {
	None=-1,//無し

	Nomal,//通常
	cSword,//ソード
	cTornado,//トルネード
	cCutter,//カッター


	cCount,//カウント用
};


//現在の状態を示す列挙
enum class Status {

	Moving,//移動
	Hovering,//ホバリング
	Squat,//しゃがみ
	Sliding,//スライディング
	Suction,//吸い込み
	CheeksStuffed,//頬張り
	SpittingOut, //吐き出し
	Attack,//攻撃中
	Damaged,//被ダメージ状態
	Dying,//やられ中
	Dead,//やられた
	Goal,//ゴール地点に到達した
};
